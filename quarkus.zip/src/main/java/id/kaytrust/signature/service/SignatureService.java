package id.kaytrust.signature.service;

public interface SignatureService {
	public String greeting(String name);
}
