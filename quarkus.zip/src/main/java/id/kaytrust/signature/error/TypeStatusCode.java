package id.kaytrust.signature.error;

import lombok.Getter;


@Getter
public enum TypeStatusCode {

	OK,
	
	ACCOUNT_NOT_FOUND;
	
	
    
}
