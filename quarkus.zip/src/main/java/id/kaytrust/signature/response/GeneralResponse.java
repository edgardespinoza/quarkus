package id.kaytrust.signature.response;

public class GeneralResponse extends HttpResponse<String> {

	public GeneralResponse(int status, String data) {
		super(status, data);
	}
	
	

}
